# AFTERHOURS

This is the repaired browser prototype. The previous update had a JavaScript syntax error in the inventory list, which stopped all buttons and game actions from initializing. This copy repairs that syntax error.

Open `index.html` in Chrome or Edge. The game is a browser prototype, not a packaged executable.
